import { Header } from "@/components/header";
import { HeroSection } from "@/components/hero-section";
import { CodeSection } from "@/components/code-section";
import { FeaturesSection } from "@/components/features-section";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Header />
      <HeroSection />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        <CodeSection />
        <FeaturesSection />
      </main>
      <Footer />
    </div>
  );
}
