import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Trophy, Gift, Star, AlertTriangle, Coins } from "lucide-react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Define reward tiers with their thresholds and benefits
const TIERS = [
  {
    name: "Bronze",
    threshold: 0,
    color: "bg-amber-700",
    benefits: ["Basic code analysis", "1 submission per day"],
  },
  {
    name: "Silver",
    threshold: 100,
    color: "bg-gray-400",
    benefits: ["Advanced code analysis", "3 submissions per day", "Email notifications"],
  },
  {
    name: "Gold",
    threshold: 500,
    color: "bg-yellow-500",
    benefits: ["Premium code analysis", "Unlimited submissions", "Priority processing", "Custom code templates"],
  },
  {
    name: "Platinum",
    threshold: 1500,
    color: "bg-blue-500",
    benefits: ["Expert-level analysis", "One-on-one mentoring sessions", "Custom project analysis", "Performance optimization"],
  },
];

// Define available rewards that can be redeemed
const REWARDS = [
  {
    id: 1,
    name: "Premium Code Analysis",
    description: "Get a detailed, in-depth analysis of your code by our expert AI",
    cost: 200,
    icon: <Star className="h-8 w-8 text-primary" />,
  },
  {
    id: 2,
    name: "Advanced Algorithm Tutorial",
    description: "Access to exclusive algorithm tutorials tailored to your skill level",
    cost: 150,
    icon: <Gift className="h-8 w-8 text-primary" />,
  },
  {
    id: 3,
    name: "Code Optimization Session",
    description: "AI-driven optimization for your projects, focusing on performance",
    cost: 300,
    icon: <Coins className="h-8 w-8 text-primary" />,
  },
];

export default function AccountPage() {
  const { isAuthenticated, user, openLoginModal } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [currentPoints, setCurrentPoints] = useState(0);
  const [redeemingRewardId, setRedeemingRewardId] = useState<number | null>(null);

  // Determine user's current tier based on points
  const getUserTier = (points: number) => {
    const reversedTiers = [...TIERS].reverse();
    return reversedTiers.find(tier => points >= tier.threshold) || TIERS[0];
  };

  // Get progress to next tier
  const getNextTierProgress = (points: number) => {
    const currentTier = getUserTier(points);
    const currentTierIndex = TIERS.findIndex(tier => tier.name === currentTier.name);
    
    if (currentTierIndex === TIERS.length - 1) {
      return 100; // Already at max tier
    }
    
    const nextTier = TIERS[currentTierIndex + 1];
    const pointsNeeded = nextTier.threshold - currentTier.threshold;
    const pointsEarned = points - currentTier.threshold;
    
    return Math.min(Math.round((pointsEarned / pointsNeeded) * 100), 100);
  };

  useEffect(() => {
    if (user) {
      setCurrentPoints(user.points || 0);
    }
  }, [user]);

  const handleRedeemReward = async (rewardId: number) => {
    if (!isAuthenticated) {
      openLoginModal();
      return;
    }

    setRedeemingRewardId(rewardId);
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", `/api/rewards/redeem/${rewardId}`);
      const data = await response.json();
      
      // Update points in local state
      setCurrentPoints(data.user.points);
      
      toast({
        title: "Reward Redeemed!",
        description: data.message,
      });
    } catch (error) {
      console.error("Error redeeming reward:", error);
      toast({
        title: "Failed to redeem reward",
        description: error instanceof Error ? error.message : "Insufficient points or service unavailable",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setRedeemingRewardId(null);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Authentication Required</AlertTitle>
          <AlertDescription>
            You need to be logged in to view your account and rewards.
          </AlertDescription>
        </Alert>
        <div className="mt-4 text-center">
          <Button onClick={openLoginModal}>Login or Register</Button>
        </div>
      </div>
    );
  }

  const currentTier = getUserTier(currentPoints);
  const nextTierProgress = getNextTierProgress(currentPoints);
  
  // Find next tier (if any)
  const currentTierIndex = TIERS.findIndex(tier => tier.name === currentTier.name);
  const nextTier = currentTierIndex < TIERS.length - 1 ? TIERS[currentTierIndex + 1] : null;
  const pointsToNextTier = nextTier ? nextTier.threshold - currentPoints : 0;

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">Your Account</h1>
      
      {user && (
        <div className="mb-8">
          <Card>
            <CardHeader className="bg-primary/5">
              <CardTitle className="text-2xl flex items-center">
                <Trophy className="mr-2 h-6 w-6 text-primary" />
                {user.username}'s Profile
              </CardTitle>
              <CardDescription>
                Manage your account and track your progress
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 pb-4">
              <div className="grid gap-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold flex items-center">
                      <span className={`h-3 w-3 rounded-full ${currentTier.color} mr-2`}></span>
                      {currentTier.name} Tier
                    </h3>
                    <span className="text-sm text-muted-foreground">
                      {currentPoints} points
                    </span>
                  </div>
                  <Progress value={nextTierProgress} className="h-2" />
                  {nextTier && (
                    <p className="text-sm text-muted-foreground mt-2">
                      {pointsToNextTier} more points until {nextTier.name} tier
                    </p>
                  )}
                </div>
                
                <div>
                  <h3 className="font-semibold mb-2">Current Benefits</h3>
                  <ul className="space-y-1">
                    {currentTier.benefits.map((benefit, index) => (
                      <li key={index} className="text-sm flex items-center">
                        <Star className="h-3.5 w-3.5 text-primary mr-2" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      <Tabs defaultValue="rewards" className="space-y-4">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="rewards">Available Rewards</TabsTrigger>
          <TabsTrigger value="tiers">Membership Tiers</TabsTrigger>
        </TabsList>
        
        <TabsContent value="rewards" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {REWARDS.map((reward) => (
              <Card key={reward.id} className="flex flex-col">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{reward.name}</CardTitle>
                      <CardDescription className="mt-1">
                        {reward.description}
                      </CardDescription>
                    </div>
                    <div className="ml-2">
                      {reward.icon}
                    </div>
                  </div>
                </CardHeader>
                <CardFooter className="mt-auto pt-0 flex justify-between items-center">
                  <div className="font-bold text-primary">
                    {reward.cost} points
                  </div>
                  <Button 
                    onClick={() => handleRedeemReward(reward.id)}
                    disabled={currentPoints < reward.cost || isLoading}
                    size="sm"
                  >
                    {isLoading && redeemingRewardId === reward.id ? (
                      <LoadingSpinner size="sm" className="mr-2" />
                    ) : null}
                    {currentPoints < reward.cost ? "Not Enough Points" : "Redeem"}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="tiers" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {TIERS.map((tier, index) => (
              <Card key={index} className={`${tier.name === currentTier.name ? 'border-primary' : ''}`}>
                <CardHeader className={`${tier.color} bg-opacity-10`}>
                  <CardTitle className="flex items-center">
                    <span className={`h-4 w-4 rounded-full ${tier.color} mr-2`}></span>
                    {tier.name} Tier
                  </CardTitle>
                  <CardDescription>
                    {tier.threshold} points required
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <ul className="space-y-2">
                    {tier.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start">
                        <Star className="h-5 w-5 text-primary mr-2 flex-shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  {tier.name === currentTier.name ? (
                    <div className="bg-primary/10 text-primary font-medium rounded-full px-3 py-1 text-sm">
                      Current Tier
                    </div>
                  ) : currentPoints >= tier.threshold ? (
                    <div className="bg-green-50 text-green-600 dark:bg-green-950 dark:text-green-400 font-medium rounded-full px-3 py-1 text-sm">
                      Unlocked
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">
                      Need {tier.threshold - currentPoints} more points
                    </div>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}