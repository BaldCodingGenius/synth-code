import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  options?: { customConfig?: RequestInit }
): Promise<Response> {
  const defaultConfig: RequestInit = {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include" as RequestCredentials,
  };

  // Correctly merge configurations
  let mergedConfig: RequestInit;
  
  if (options?.customConfig) {
    // Start with the default config
    mergedConfig = { ...defaultConfig };
    
    // Merge everything except headers
    Object.keys(options.customConfig).forEach(key => {
      if (key !== 'headers') {
        (mergedConfig as any)[key] = (options.customConfig as any)[key];
      }
    });
    
    // Merge headers separately
    if (options.customConfig.headers) {
      mergedConfig.headers = { 
        ...defaultConfig.headers as Record<string, string>, 
        ...options.customConfig.headers as Record<string, string>
      };
    }
  } else {
    mergedConfig = defaultConfig;
  }

  const res = await fetch(url, mergedConfig);

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
