import { useState, useRef, useEffect } from "react";

interface LineProps {
  number: number;
  content: string;
}

interface LineWithLanguageProps extends LineProps {
  language: string;
}

const Line = ({ number, content, language }: LineWithLanguageProps) => {
  // Function to tokenize and highlight code
  const highlightCode = (code: string) => {
    // HTML tag highlighting
    if (language === "html") {
      const tagRegex = /(&lt;[\/]?)([\w\-]+)([^&]*?)(&gt;)/g;
      const attributeRegex = /(\s+)([a-zA-Z\-]+)(\s*=\s*)(["'])(.*?)\4/g;
      const doctypeRegex = /(&lt;!DOCTYPE.*?&gt;)/g;
      const commentRegex = /(&lt;!--.*?--&gt;)/g;

      return code
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(doctypeRegex, '<span class="text-gray-500">$1</span>')
        .replace(commentRegex, '<span class="text-gray-500">$1</span>')
        .replace(tagRegex, '$1<span class="text-blue-500">$2</span>$3$4')
        .replace(attributeRegex, '$1<span class="text-purple-500">$2</span>$3$4<span class="text-green-500">$5</span>$4');
    } 
    // Regular code highlighting
    else {
      // Replace with more comprehensive syntax highlighting in a real application
      const keywordRegex = /\b(function|if|return|const|let|var|for|while|do|switch|case|break)\b/g;
      const functionRegex = /([a-zA-Z0-9_]+)(?=\s*\()/g;
      const stringRegex = /(["'`])(.*?)\1/g;
      const numberRegex = /\b(\d+)\b/g;
      const commentRegex = /(\/\/.*)/g;

      return code
        .replace(keywordRegex, '<span class="text-purple-500">$&</span>')
        .replace(functionRegex, '<span class="text-blue-500">$&</span>')
        .replace(stringRegex, '<span class="text-green-500">$&</span>')
        .replace(numberRegex, '<span class="text-amber-500">$&</span>')
        .replace(commentRegex, '<span class="text-gray-500">$&</span>');
    }
  };

  return (
    <div className="flex font-mono text-sm leading-snug">
      <span className="inline-block w-8 pr-2 text-right text-gray-500 select-none">{number}</span>
      <span className="flex-1" dangerouslySetInnerHTML={{ __html: highlightCode(content) }} />
    </div>
  );
};

interface CodeEditorProps {
  initialCode?: string;
  language?: string;
  onChange?: (code: string) => void;
}

export function CodeEditor({ initialCode = "", language = "javascript", onChange }: CodeEditorProps) {
  const defaultCode = initialCode || 
`function fibonacci(n) {
  // Calculate fibonacci number
  if (n <= 1) {
    return n;
  }
  
  // This is inefficient for large values of n
  return fibonacci(n - 1) + fibonacci(n - 2);
}

const result = fibonacci(10);
console.log(result);`;

  const [code, setCode] = useState(defaultCode);
  const [selectedLanguage, setSelectedLanguage] = useState(language);
  
  useEffect(() => {
    setSelectedLanguage(language);
  }, [language]);
  
  const handleCodeChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newCode = e.target.value;
    setCode(newCode);
    if (onChange) {
      onChange(newCode);
    }
  };

  const lines = code.split('\n');

  return (
    <div className="bg-white dark:bg-gray-800 rounded-md shadow overflow-hidden">
      <div className="relative border border-gray-200 dark:border-gray-700 rounded-md">
        <div className="overflow-x-auto relative">
          <div className="absolute inset-0 opacity-0">
            <textarea 
              value={code}
              onChange={handleCodeChange}
              className="w-full h-full resize-none font-mono p-4 text-sm leading-snug"
            />
          </div>
          <pre className="p-4 font-mono text-sm leading-snug relative pointer-events-none">
            {lines.map((line, index) => (
              <Line key={index} number={index + 1} content={line} language={selectedLanguage} />
            ))}
          </pre>
        </div>
      </div>
    </div>
  );
}
