import { useState } from "react";
import { CodeEditor } from "@/components/ui/code-editor";
import { Button } from "@/components/ui/button";
import { Wand2, Send, ArrowDown, Check, X, Code } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function CodeSection() {
  const [code, setCode] = useState("");
  const [improvedCode, setImprovedCode] = useState("");
  const [language, setLanguage] = useState("javascript");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [complexity, setComplexity] = useState({ complexity: "", score: 0, suggestions: [] });
  const [lastSubmissionId, setLastSubmissionId] = useState<number | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [pointsEarned, setPointsEarned] = useState(0);
  const { isAuthenticated, openLoginModal, user } = useAuth();
  const { toast } = useToast();

  const handleGenerateCode = async () => {
    if (!isAuthenticated) {
      openLoginModal();
      return;
    }

    if (!code.trim()) {
      toast({
        title: "Empty code",
        description: "Please write or paste some code first.",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      if (!user) {
        throw new Error("User not authenticated");
      }

      // Submit the code to the API for AI processing
      const response = await apiRequest("POST", "/api/code/submit", {
        code,
        language
      }, {
        customConfig: {
          headers: {
            "user-id": user.id.toString()
          }
        }
      });
      
      const data = await response.json();
      setLastSubmissionId(data.submissionId);
      
      // Poll for results - in a real app, this could be done with WebSockets
      let attempts = 0;
      const maxAttempts = 30; // 30 seconds max wait
      
      const pollInterval = setInterval(async () => {
        attempts++;
        
        try {
          const feedbackResponse = await apiRequest("GET", `/api/code/feedback/${data.submissionId}`, null, {
            customConfig: {
              headers: {
                "user-id": user.id.toString()
              }
            }
          });
          
          const feedbackData = await feedbackResponse.json();
          
          if (feedbackData.processed) {
            clearInterval(pollInterval);
            
            // Parse feedback data
            const parsedFeedback = JSON.parse(feedbackData.feedback);
            setFeedback(parsedFeedback.feedback || "");
            setImprovedCode(feedbackData.improvedCode || "");
            setComplexity(parsedFeedback.complexity || { complexity: "O(n)", score: 5, suggestions: [] });
            
            // Calculate points earned (base 10 + complexity score)
            const points = 10 + Math.round(parsedFeedback.complexity?.score || 5);
            setPointsEarned(points);
            
            // Show results
            setShowResults(true);
            setIsProcessing(false);
          }
          
          if (attempts >= maxAttempts) {
            clearInterval(pollInterval);
            setIsProcessing(false);
            toast({
              title: "Processing taking longer than expected",
              description: "Your code is still being analyzed. Check back in a moment.",
            });
          }
        } catch (error) {
          console.error("Error polling for feedback:", error);
          if (attempts >= maxAttempts) {
            clearInterval(pollInterval);
            setIsProcessing(false);
          }
        }
      }, 1000);
      
      toast({
        title: "Code submitted for analysis",
        description: "We're analyzing your code with AI. Results will appear shortly.",
      });
    } catch (error) {
      console.error("Error generating code feedback:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to process code",
        variant: "destructive"
      });
      setIsProcessing(false);
    }
  };

  const handleSubmitCode = async () => {
    if (!isAuthenticated) {
      openLoginModal();
      return;
    }

    if (!code.trim()) {
      toast({
        title: "Empty code",
        description: "Please write or paste some code first.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      if (!user) {
        throw new Error("User not authenticated");
      }
      
      // Submit the code to the API
      const response = await apiRequest("POST", "/api/code/submit", {
        code,
        language
      }, {
        customConfig: {
          headers: {
            "user-id": user.id.toString()
          }
        }
      });
      
      const data = await response.json();
      
      toast({
        title: "Code submitted successfully",
        description: "Your code has been submitted for review. You'll receive feedback soon.",
      });
      
      // Clear the form after successful submission
      setCode("");
      setShowResults(false);
    } catch (error) {
      console.error("Error submitting code:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit code",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUseImprovedCode = () => {
    if (improvedCode) {
      setCode(improvedCode);
      setShowResults(false);
      toast({
        title: "Code updated",
        description: "The optimized code has been loaded in the editor.",
      });
    }
  };

  return (
    <Card className="mb-8 bg-white dark:bg-gray-800 shadow overflow-hidden">
      <CardHeader className="px-4 py-5 sm:px-6 flex flex-col sm:flex-row justify-between items-start sm:items-center border-b">
        <div>
          <CardTitle className="text-lg font-medium text-gray-900 dark:text-white">Code Editor</CardTitle>
          <CardDescription className="mt-1 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
            Write or paste your code for review
          </CardDescription>
        </div>
        <div className="mt-2 sm:mt-0">
          <Select defaultValue={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-[180px] bg-gray-100 dark:bg-gray-700 text-sm">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="javascript">JavaScript</SelectItem>
              <SelectItem value="python">Python</SelectItem>
              <SelectItem value="java">Java</SelectItem>
              <SelectItem value="cpp">C++</SelectItem>
              <SelectItem value="typescript">TypeScript</SelectItem>
              <SelectItem value="html">HTML</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="bg-gray-50 dark:bg-gray-900 p-4">
        <CodeEditor 
          initialCode={code} 
          language={language} 
          onChange={setCode}
        />
        <div className="mt-4 flex justify-end space-x-3">
          <Button
            variant="secondary"
            className="bg-purple-500 hover:bg-purple-600 text-white"
            onClick={handleGenerateCode}
            disabled={isProcessing || isSubmitting}
          >
            {isProcessing ? <LoadingSpinner size="sm" className="mr-2" /> : <Wand2 className="mr-2 h-4 w-4" />}
            Generate/Fix Code
          </Button>
          <Button
            onClick={handleSubmitCode}
            disabled={isProcessing || isSubmitting}
          >
            {isSubmitting ? <LoadingSpinner size="sm" className="mr-2" /> : <Send className="mr-2 h-4 w-4" />}
            Submit Code
          </Button>
        </div>
      </CardContent>
      
      {showResults && (
        <CardFooter className="bg-white dark:bg-gray-800 p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="w-full">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">AI Analysis Results</h3>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-500 dark:text-gray-400">Points earned:</span>
                <span className="font-bold text-primary">{pointsEarned}</span>
              </div>
            </div>
            
            <Tabs defaultValue="feedback">
              <TabsList className="mb-4">
                <TabsTrigger value="feedback">Feedback</TabsTrigger>
                <TabsTrigger value="improved">Improved Code</TabsTrigger>
                <TabsTrigger value="complexity">Complexity</TabsTrigger>
              </TabsList>
              
              <TabsContent value="feedback" className="space-y-4">
                <div className="p-4 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                  <p className="whitespace-pre-line text-gray-800 dark:text-gray-200">{feedback}</p>
                </div>
              </TabsContent>
              
              <TabsContent value="improved">
                {improvedCode ? (
                  <div className="space-y-4">
                    <CodeEditor 
                      initialCode={improvedCode} 
                      language={language} 
                      onChange={code => {}}
                    />
                    <Button 
                      onClick={handleUseImprovedCode}
                      className="w-full"
                    >
                      <ArrowDown className="mr-2 h-4 w-4" />
                      Use Improved Code
                    </Button>
                  </div>
                ) : (
                  <Alert>
                    <Code className="h-4 w-4" />
                    <AlertTitle>No improved code available</AlertTitle>
                    <AlertDescription>
                      The AI was unable to generate improved code for this submission.
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>
              
              <TabsContent value="complexity">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-md border border-gray-200 dark:border-gray-700">
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">Complexity Rating</h4>
                      <p className="text-xl font-bold text-primary">{complexity.complexity}</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">Score</h4>
                      <p className="text-xl font-bold text-primary">{complexity.score}/10</p>
                    </div>
                  </div>
                  
                  <div className="p-4 rounded-md border border-gray-200 dark:border-gray-700">
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">Optimization Suggestions</h4>
                    <ul className="space-y-2">
                      {complexity.suggestions.length > 0 ? (
                        complexity.suggestions.map((suggestion, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                            <p className="text-gray-700 dark:text-gray-300">{suggestion}</p>
                          </li>
                        ))
                      ) : (
                        <li className="flex items-center">
                          <X className="h-5 w-5 text-gray-400 mr-2" />
                          <p className="text-gray-500">No suggestions available</p>
                        </li>
                      )}
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}
