import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema } from "@shared/schema";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const extendedLoginSchema = loginSchema.extend({
  rememberMe: z.boolean().optional(),
});

type LoginFormValues = z.infer<typeof extendedLoginSchema>;

export function FeaturesSection() {
  const { login, openLoginModal, isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(extendedLoginSchema),
    defaultValues: {
      username: "",
      password: "",
      rememberMe: false,
    },
  });

  const onSubmit = async (data: LoginFormValues) => {
    setIsSubmitting(true);
    try {
      const response = await apiRequest("POST", "/api/login", {
        username: data.username,
        password: data.password,
      });
      
      const userData = await response.json();
      login(userData);
      
      toast({
        title: "Login successful",
        description: `Welcome back, ${userData.username}!`,
      });
      
      form.reset();
    } catch (error) {
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRedeemPoints = () => {
    if (!isAuthenticated) {
      openLoginModal();
      return;
    }
    
    toast({
      title: "Points redeemed",
      description: "You've successfully redeemed your points for this item.",
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Login Form */}
      <Card className="bg-white dark:bg-gray-800 shadow overflow-hidden">
        <CardHeader className="px-4 py-5 sm:px-6 border-b">
          <CardTitle className="text-lg font-medium text-gray-900 dark:text-white">Account Login</CardTitle>
          <CardDescription className="mt-1 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
            Login to access premium features
          </CardDescription>
        </CardHeader>
        <CardContent className="px-4 py-5 sm:p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 dark:text-gray-300">Username</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="your-username" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-gray-700 dark:text-gray-300">Password</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="••••••••" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <FormField
                    control={form.control}
                    name="rememberMe"
                    render={({ field }) => (
                      <FormItem className="flex items-center space-x-2">
                        <FormControl>
                          <Checkbox 
                            checked={field.value} 
                            onCheckedChange={field.onChange} 
                          />
                        </FormControl>
                        <Label 
                          htmlFor="rememberMe" 
                          className="text-sm text-gray-700 dark:text-gray-300"
                        >
                          Remember me
                        </Label>
                      </FormItem>
                    )}
                  />
                </div>
                <div className="text-sm">
                  <a href="#" className="font-medium text-primary hover:text-primary/80">
                    Forgot password?
                  </a>
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                disabled={isSubmitting}
              >
                Login
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Points and Rewards */}
      <Card className="bg-white dark:bg-gray-800 shadow overflow-hidden">
        <CardHeader className="px-4 py-5 sm:px-6 border-b">
          <CardTitle className="text-lg font-medium text-gray-900 dark:text-white">Points & Rewards</CardTitle>
          <CardDescription className="mt-1 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
            Earn points by using Synth features
          </CardDescription>
        </CardHeader>
        <CardContent className="px-4 py-5 sm:p-6">
          <div className="mb-5">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-medium text-gray-700 dark:text-gray-300">Your Points</h4>
              <span className="text-2xl font-bold text-primary">750</span>
            </div>
            <Progress className="mt-2" value={75} />
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">250 more points to reach Gold tier</p>
          </div>
          
          <div className="space-y-4">
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-md flex justify-between items-center">
              <div>
                <h5 className="font-medium text-gray-900 dark:text-white">Premium Code Analysis</h5>
                <p className="text-sm text-gray-500 dark:text-gray-400">500 points</p>
              </div>
              <Button
                onClick={handleRedeemPoints}
                size="sm"
                variant="secondary"
                className="bg-green-500 hover:bg-green-600 text-white"
              >
                Redeem
              </Button>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-md flex justify-between items-center">
              <div>
                <h5 className="font-medium text-gray-900 dark:text-white">Advanced Algorithm Tutorial</h5>
                <p className="text-sm text-gray-500 dark:text-gray-400">300 points</p>
              </div>
              <Button
                onClick={handleRedeemPoints}
                size="sm"
                variant="secondary"
                className="bg-green-500 hover:bg-green-600 text-white"
              >
                Redeem
              </Button>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-md flex justify-between items-center">
              <div>
                <h5 className="font-medium text-gray-900 dark:text-white">Code Optimization Session</h5>
                <p className="text-sm text-gray-500 dark:text-gray-400">800 points</p>
              </div>
              <Button
                disabled
                size="sm"
                variant="secondary"
              >
                Redeem
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
