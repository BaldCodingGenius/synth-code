import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-24">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 dark:text-white sm:text-5xl sm:tracking-tight lg:text-6xl">
            Welcome to <span className="text-primary">Synth</span>
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500 dark:text-gray-300">
            AI-powered code review and learning platform. Get real-time feedback, fix issues, and enhance your coding skills.
          </p>
          <div className="mt-8 flex justify-center">
            <div className="rounded-md shadow">
              <Button 
                className="px-8 py-3 h-auto text-base md:py-4 md:text-lg md:px-10"
              >
                Get started
              </Button>
            </div>
            <div className="ml-3 rounded-md shadow">
              <Button 
                variant="outline"
                className="px-8 py-3 h-auto text-base md:py-4 md:text-lg md:px-10"
              >
                Learn more
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
