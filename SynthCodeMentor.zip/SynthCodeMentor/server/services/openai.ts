import OpenAI from "openai";

// Ensure the API key is set
if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not set in environment variables");
}

// Initialize the OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * Analyzes code and provides feedback and improvements
 */
export async function generateCodeFeedback(code: string, language: string): Promise<{
  feedback: string;
  improvedCode?: string;
}> {
  try {
    // Create a system message
    const systemPrompt = `You are an expert code reviewer and mentor specializing in ${language}. 
    Your task is to analyze the provided code and:
    1. Give constructive feedback on the code quality, style, and structure
    2. Identify potential bugs or edge cases
    3. Suggest improvements for readability and maintainability
    4. Provide an improved version of the code if appropriate
    
    Please format your response in a clear, educational way.`;

    // User message
    const userPrompt = `Please review this ${language} code and provide feedback:
    
    \`\`\`${language}
    ${code}
    \`\`\``;

    // Make the API request
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: 0.5,
      max_tokens: 2000,
    });

    // Parse the response to extract feedback and improved code
    const responseText = response.choices[0].message.content || "";
    
    // Simple parsing logic - in a real app, you might want more sophisticated parsing
    const improvedCodePattern = /```(?:\w+)?\s*([\s\S]*?)```/g;
    let match;
    const matches = [];
    
    // Collect all matches manually instead of using matchAll which can have compatibility issues
    while ((match = improvedCodePattern.exec(responseText)) !== null) {
      matches.push(match);
    }
    
    const improvedCode = matches.length > 0 ? matches[matches.length - 1][1] : undefined;
    
    // Remove the code blocks from the feedback
    let feedback = responseText;
    matches.forEach(match => {
      feedback = feedback.replace(match[0], '');
    });
    
    feedback = feedback.trim();
    
    return {
      feedback,
      improvedCode
    };
  } catch (error) {
    console.error("Error generating code feedback:", error);
    return {
      feedback: "Sorry, there was an error processing your code. Please try again later."
    };
  }
}

/**
 * Analyzes code complexity and provides a score and suggestions
 */
export async function analyzeCodeComplexity(code: string, language: string): Promise<{
  complexity: string;
  score: number;
  suggestions: string[];
}> {
  try {
    const prompt = `As a code complexity expert, analyze the following ${language} code and provide:
    1. The estimated time complexity (O notation)
    2. A complexity score from 1-10 (where 1 is very simple and 10 is very complex)
    3. A list of 2-3 suggestions for improving performance or reducing complexity
    
    Present your response as a valid JSON object with the following fields:
    - complexity: the Big O notation as a string
    - score: a number from 1-10
    - suggestions: an array of strings with suggestions
    
    Here's the code:
    
    \`\`\`${language}
    ${code}
    \`\`\``;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You analyze code complexity and provide structured feedback as JSON." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    const resultText = response.choices[0].message.content || "";
    const result = JSON.parse(resultText);
    
    return {
      complexity: result.complexity || "O(n)",
      score: Math.min(10, Math.max(1, result.score)) || 5,
      suggestions: Array.isArray(result.suggestions) ? result.suggestions : []
    };
  } catch (error) {
    console.error("Error analyzing code complexity:", error);
    return {
      complexity: "O(n)",
      score: 5,
      suggestions: ["Could not analyze complexity. Please try again with valid code."]
    };
  }
}