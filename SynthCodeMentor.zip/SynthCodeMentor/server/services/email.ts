import nodemailer from 'nodemailer';

// Email transporter
let transporter: nodemailer.Transporter;

/**
 * Initialize the email service with a test account or actual SMTP settings
 */
export const initEmailService = async () => {
  try {
    // If SMTP settings are not provided, create a test account using Ethereal
    if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
      console.log('SMTP settings not found, creating a test account...');
      
      // Create a test account at ethereal.email
      const testAccount = await nodemailer.createTestAccount();
      
      // Create a transporter object using the test account SMTP details
      transporter = nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
          user: testAccount.user,
          pass: testAccount.pass,
        },
      });
      
      console.log('Email service initialized');
      console.log(`Test email inbox: https://ethereal.email/login (${testAccount.user} / ${testAccount.pass})`);
    } else {
      // Create a transporter with the provided SMTP settings
      transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });
      
      console.log('Email service initialized with provided SMTP settings');
    }
    
    // Verify the connection
    await transporter.verify();
  } catch (error) {
    console.error('Failed to initialize email service:', error);
  }
};

/**
 * Send a notification email when a new code submission is received
 */
export const sendCodeSubmissionNotification = async (
  to: string,
  username: string,
  language: string,
  code: string
): Promise<void> => {
  if (!transporter) {
    console.warn('Email service not initialized');
    return;
  }
  
  try {
    // Format the code for better display in the email
    const formattedCode = code.length > 500 
      ? code.substring(0, 500) + '...' 
      : code;
    
    // Create the email content
    const mailOptions = {
      from: process.env.SMTP_FROM || '"Synth Code Review" <noreply@synthcode.com>',
      to,
      subject: `New Code Submission from ${username}`,
      text: `
User ${username} has submitted new ${language} code for review:

--------------------
${formattedCode}
--------------------

View the full submission in the admin dashboard.
      `,
      html: `
<div style="font-family: Arial, sans-serif; line-height: 1.6;">
  <h2>New Code Submission</h2>
  <p>User <strong>${username}</strong> has submitted new <strong>${language}</strong> code for review:</p>
  
  <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; font-family: monospace; white-space: pre-wrap; overflow-x: auto;">
    ${formattedCode.replace(/</g, '&lt;').replace(/>/g, '&gt;')}
  </div>
  
  <p style="margin-top: 20px;">View the full submission in the <a href="#">admin dashboard</a>.</p>
</div>
      `,
    };
    
    // Send the email
    const info = await transporter.sendMail(mailOptions);
    
    // For test accounts, log the preview URL
    if (info.messageId && info.previewURL) {
      console.log(`Email sent: ${info.messageId}`);
      console.log(`Preview URL: ${info.previewURL}`);
    }
  } catch (error) {
    console.error('Failed to send email notification:', error);
  }
};