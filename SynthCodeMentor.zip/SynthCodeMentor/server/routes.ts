import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, insertUserSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { z } from "zod";
import { generateCodeFeedback, analyzeCodeComplexity } from "./services/openai";
import { initEmailService, sendCodeSubmissionNotification } from "./services/email";

// Initialize the email service when the server starts
initEmailService().catch(console.error);

// Custom middleware to verify user is authenticated
const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // This is a simplified authentication check for our demo
    // In a real app, this would verify JWT tokens or session cookies
    const userId = parseInt(req.headers['user-id'] as string || '');
    
    if (isNaN(userId)) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    
    // Add the user to the request object
    (req as any).user = user;
    next();
  } catch (error) {
    res.status(500).json({ message: "Authentication error" });
  }
};

// Schema for code submission
const codeSubmissionSchema = z.object({
  language: z.string().min(1),
  code: z.string().min(1),
});

// Schema for updating points
const updatePointsSchema = z.object({
  points: z.number().int(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/register", async (req, res) => {
    try {
      const parsedUser = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(parsedUser.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const newUser = await storage.createUser(parsedUser);
      const { password, ...userWithoutPassword } = newUser;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(loginData.username);
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      if (user.password !== loginData.password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      const { password, ...userWithoutPassword } = user;
      
      // For a real app, this would be the place to create a JWT or session
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // User data route
  app.get("/api/user/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = user;
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Code submission and AI review
  app.post("/api/code/submit", authenticate, async (req, res) => {
    try {
      const user = (req as any).user;
      const { language, code } = codeSubmissionSchema.parse(req.body);
      
      // Store the code submission
      const submission = await storage.submitCode(user.id, language, code);
      
      // Send email notification (async)
      const userEmail = "blakesilver321@gmail.com"; // User's specified email
      sendCodeSubmissionNotification(userEmail, user.username, language, code)
        .catch(err => console.error("Failed to send email notification:", err));
      
      // Process the code with AI (async)
      setTimeout(async () => {
        try {
          // Get AI feedback on the code
          const feedback = await generateCodeFeedback(code, language);
          
          // Analyze code complexity
          const complexity = await analyzeCodeComplexity(code, language);
          
          // Update submission with feedback
          await storage.updateSubmissionFeedback(
            submission.id, 
            JSON.stringify({ ...feedback, complexity }), 
            feedback.improvedCode
          );
          
          // Award points based on submission and complexity
          // More complex code = more points (1-10 based on AI analysis)
          const pointsToAward = 10 + Math.round(complexity.score);
          await storage.updateUserPoints(user.id, pointsToAward);
        } catch (processingError) {
          console.error("Error processing code submission:", processingError);
        }
      }, 100); // Small delay before processing
      
      return res.status(200).json({ 
        message: "Code submitted successfully", 
        submissionId: submission.id 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error in code submission:", error);
      return res.status(500).json({ message: "Failed to process code submission" });
    }
  });
  
  // Get code submission feedback
  app.get("/api/code/feedback/:id", authenticate, async (req, res) => {
    try {
      const submissionId = parseInt(req.params.id);
      if (isNaN(submissionId)) {
        return res.status(400).json({ message: "Invalid submission ID" });
      }
      
      const submission = await storage.getSubmission(submissionId);
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      
      // Verify the user owns this submission
      const user = (req as any).user;
      if (submission.userId !== user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      return res.status(200).json(submission);
    } catch (error) {
      console.error("Error retrieving submission feedback:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get user's submissions
  app.get("/api/code/submissions", authenticate, async (req, res) => {
    try {
      const user = (req as any).user;
      const submissions = await storage.getUserSubmissions(user.id);
      
      return res.status(200).json(submissions);
    } catch (error) {
      console.error("Error retrieving user submissions:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Update user points
  app.post("/api/user/points", authenticate, async (req, res) => {
    try {
      const user = (req as any).user;
      const { points } = updatePointsSchema.parse(req.body);
      
      const updatedUser = await storage.updateUserPoints(user.id, points);
      const { password, ...userWithoutPassword } = updatedUser;
      
      return res.status(200).json({
        message: "Points updated successfully",
        user: userWithoutPassword
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error updating points:", error);
      return res.status(500).json({ message: "Failed to update points" });
    }
  });
  
  // Redeem points for a reward
  app.post("/api/rewards/redeem/:rewardId", authenticate, async (req, res) => {
    try {
      const user = (req as any).user;
      const rewardId = parseInt(req.params.rewardId);
      
      if (isNaN(rewardId)) {
        return res.status(400).json({ message: "Invalid reward ID" });
      }
      
      // Mock reward point costs
      const rewards = {
        1: { name: "Premium Code Analysis", cost: 500 },
        2: { name: "Advanced Algorithm Tutorial", cost: 300 },
        3: { name: "Code Optimization Session", cost: 800 }
      };
      
      const reward = rewards[rewardId as keyof typeof rewards];
      if (!reward) {
        return res.status(404).json({ message: "Reward not found" });
      }
      
      // Check if user has enough points
      if (user.points < reward.cost) {
        return res.status(400).json({ 
          message: "Not enough points", 
          required: reward.cost, 
          current: user.points 
        });
      }
      
      // Deduct points
      const updatedUser = await storage.updateUserPoints(user.id, -reward.cost);
      const { password, ...userWithoutPassword } = updatedUser;
      
      return res.status(200).json({
        message: `Successfully redeemed ${reward.name}`,
        pointsDeducted: reward.cost,
        user: userWithoutPassword
      });
    } catch (error) {
      console.error("Error redeeming reward:", error);
      return res.status(500).json({ message: "Failed to redeem reward" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
