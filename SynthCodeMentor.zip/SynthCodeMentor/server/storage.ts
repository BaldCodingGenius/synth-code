import { users, type User, type InsertUser } from "@shared/schema";

// Interfaces for code submissions and feedback
export interface CodeSubmission {
  id: number;
  userId: number;
  language: string;
  code: string;
  timestamp: Date;
  processed: boolean;
  feedback?: string;
  improvedCode?: string;
}

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User>;
  
  // Code submission methods
  submitCode(userId: number, language: string, code: string): Promise<CodeSubmission>;
  getUserSubmissions(userId: number): Promise<CodeSubmission[]>;
  getSubmission(id: number): Promise<CodeSubmission | undefined>;
  updateSubmissionFeedback(id: number, feedback: string, improvedCode?: string): Promise<CodeSubmission>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private codeSubmissions: Map<number, CodeSubmission>;
  currentId: number;
  currentSubmissionId: number;

  constructor() {
    this.users = new Map();
    this.codeSubmissions = new Map();
    this.currentId = 1;
    this.currentSubmissionId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      points: 0 
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserPoints(userId: number, points: number): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    // Update user points
    const updatedUser = {
      ...user,
      points: user.points + points
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async submitCode(userId: number, language: string, code: string): Promise<CodeSubmission> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const id = this.currentSubmissionId++;
    const submission: CodeSubmission = {
      id,
      userId,
      language,
      code,
      timestamp: new Date(),
      processed: false
    };
    
    this.codeSubmissions.set(id, submission);
    return submission;
  }
  
  async getUserSubmissions(userId: number): Promise<CodeSubmission[]> {
    return Array.from(this.codeSubmissions.values())
      .filter(submission => submission.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }
  
  async getSubmission(id: number): Promise<CodeSubmission | undefined> {
    return this.codeSubmissions.get(id);
  }
  
  async updateSubmissionFeedback(id: number, feedback: string, improvedCode?: string): Promise<CodeSubmission> {
    const submission = this.codeSubmissions.get(id);
    if (!submission) {
      throw new Error(`Submission with ID ${id} not found`);
    }
    
    const updatedSubmission: CodeSubmission = {
      ...submission,
      feedback,
      improvedCode,
      processed: true
    };
    
    this.codeSubmissions.set(id, updatedSubmission);
    return updatedSubmission;
  }
}

export const storage = new MemStorage();
